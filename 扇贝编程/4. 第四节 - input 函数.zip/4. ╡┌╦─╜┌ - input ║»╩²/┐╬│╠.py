answer = int(input('秋香的生日是8月几号？'))
if answer == 15:
  print('答对了，我同意这门亲事')
else:
  print('生日都说错了？秋香不能嫁给你')